color codes: 
primary: 
{
BLUE
HEX: #31A8FF
RGB: (49, 168, 255)
CMYK: (64, 24, 0, 0)
PANTONE: PMS 279 C
}

secondary: {
NAVY BLUE
HEX: #001E36
RGB: (0, 30, 54)
CMYK: (96, 79, 49, 61)
PANTONE: PMS 289 C
}

textColor: 
{
#18152E
}